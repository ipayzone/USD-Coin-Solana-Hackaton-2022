package pisto.net.pos.activity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import pisto.net.pos.R;
public class WebViewDemo extends Activity {
    private WebView webView;
    Activity activity ;
    private ProgressDialog progDailog;

    @SuppressLint("NewApi")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.common_webview);
        activity = this;
        progDailog = ProgressDialog.show(activity, "Loading","Please wait...", true);
        progDailog.setCancelable(false);
        webView = (WebView) findViewById(R.id.webView);
        webView.requestFocus();
        webView.setInitialScale(70);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setPadding(0, 0, 0, 0);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setBuiltInZoomControls(false);
        //webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        //webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(false);
        webView.setWebViewClient(new WebViewClient(){

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                progDailog.show();
                view.loadUrl(url);
                return true;
            }
            @Override
            public void onPageFinished(WebView view, final String url) {
                progDailog.dismiss();
                //MainActivity.intent.setClass(WebViewDemo.this, ProductScreen.class);
                //startActivity(MainActivity.intent);

            }
        });

        String URL = "https://app.solanapay.com/new?recipient=52TohhpN5URpUH6KnfsYM3TecPUxFurUjGw8kwivSi9H&label=Technoprepay%20Solutions";
        webView.loadUrl(URL);
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //MainActivity.intent.setClass(WebViewDemo.this, ProductScreen.class);
            //startActivity(MainActivity.intent);
            //WebViewDemo.this.finish();
            Bundle b = new Bundle();
            b.putShort("where", (short) 0);

            Intent intent = new Intent();
            intent.putExtras(b);
            intent.setClass(WebViewDemo.this, MainActivity.class);
            startActivity(intent);
            WebViewDemo.this.finish();
        }
        return true;
    }



}
