# Solana POS -Summercamp Hackathon 2022
Sample code for Solana POS Hackathon 2021
Functions developed for accepting USDT and Solana 
at point of sale terminal.
Deposit funds directly in merchants Solana non custodial account
print receipts and reports
For sample implementation refer to Solana POS on google play.

* Uses solscan.io to Monitor Account, Balance and transactions
* Uses ___________ to monitor exchange rate
* 


Developed by Juan Carlos Vera
www.technoprepay.com
